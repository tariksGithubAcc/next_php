<?php

$name = "Tarik is randwaa";
echo "The length of this string is" . strlen($name);

echo "<br>";

echo str_word_count($name);

echo "<br>";

echo strrev($name);
echo "<br>";

// To search a character in the given string:-

echo strpos($name, "is");
echo "<br>";

// To replace old word with new word:-
echo str_replace("Tarik","Prabhjot",$name);
echo"<br>";

// To repeat the string repeatedly number of times:-
echo str_repeat($name, 456);
echo "<br>";

// To remove spaces from right and left side:-
echo "<pre>";
echo rtrim("   Tera kuch ni ho sakta nannu to barbaad hai      ");
echo "</pre>";
echo "<br>";

?>