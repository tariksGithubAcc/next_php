<?php

// String:-
$name = "Tarik";
$aukaat = "Randwaa";

echo "$name ek $aukaat hai";

echo "<br>";

// Integer:-
$first_number = 2000;
$second_number = 30000;

echo "$first_number and $second_number";
echo "<br>";

// Float:-
$first_floating_point_number = 45.36;
$second_floating_point_number = 45.12;

echo "$first_floating_point_number and $second_floating_point_number";
echo "<br>";
echo var_dump($first_floating_point_number);

// Boolean:-
$string_one = True;
$string_two = False;
echo var_dump($string_one);
echo "<br>";
echo var_dump($string_two);
echo "<br>";

// Array:-

$friends = array("Tarik","Nitish","Arjun","Prabhjot");
echo var_dump($friends);
echo "<br>";
echo $friends[0];   
echo "<br>";

// NULL:-

$age = NULL;
echo var_dump($age);
?>