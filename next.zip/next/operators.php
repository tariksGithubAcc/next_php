<?php

// Airthmatic operators:-
$a = 10;
$b = 10;

echo "The sum of a and b is" . ($a+$b);
echo "<br>";

// Assignment operator:-
$x = $a;
echo "The value of x is" . $x;
echo "<br>";

$a += 20;
echo "The updated value of a is" . $a;
echo "<br>";

// Comparision operators:-

$x = 45;
$y = 45;
                                                
echo "Return true if both a and b are same" . var_dump($x==$y);
echo "<br>";

echo "Return false if both a and b are not same" . var_dump($x<>$y);
echo "<br>";

// Logical Operators:-

$a = true;
$b = false;

echo "Print the result of and operation false if both operands are not same is" . var_dump($a && $b);
echo "<br>";

echo "The invertible of a is not operator a" . var_dump(!$a);
echo "<br>";

?>