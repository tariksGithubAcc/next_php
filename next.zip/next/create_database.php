<?php

$servername = "localhost";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password);

echo "Connection was successfull";
echo "<br>";
echo "<br>";

$sql = "CREATE DATABASE tarik2";
$result = mysqli_query($conn, $sql);

echo "Database was successfully created" . $result;
echo "<br>";
echo "<br>";
?>