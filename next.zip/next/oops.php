<?php

class Player{
    public $name;
    public $speed;

    function set_name($name){
        $this->name = $name;
    }

    function get_name(){
        return $this->name;
    }


}

$player1 = new Player();
$player1->set_name("Tarik");
echo $player1->get_name();
echo "<br>";
echo "<br>";

$player2 = new Player();
$player2->set_name("Rohan");
echo $player2->get_name();
echo "<br>";
echo "<br>";

$player3 = new Player();
$player3->set_name("Vikas");
echo $player3->get_name();
echo "<br>";
echo "<br>";

$player4 = new Player();
$player4->set_name("Ravi");
echo $player4->get_name();
echo "<br>";
echo "<br>";
?>