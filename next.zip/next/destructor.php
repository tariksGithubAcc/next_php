<?php

class Employee{
    public $name;
    public $salary;

    function __construct($name, $salary){
        $this->name = $name;
        $this->salary = $salary;
    }

    function __destruct(){
        echo "This is destructing" . $this->name;
        echo "<br>";
        echo "<br>";
    }

}

$employee1 = new Employee("Tarik", 100000);
echo $employee1->name;
echo "<br>";
echo "<br>";
echo $employee1->salary;
echo "<br>";
echo "<br>";

$employee2 = new Employee("Rohan", 20000);
echo $employee2->name;
echo "<br>";
echo "<br>";
echo $employee2->salary;
echo "<br>";
echo "<br>";

?>