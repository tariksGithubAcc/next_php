<?php

// constructor without arguments:-
class Animal{
    public $name;
    public $color;


    function __construct(){
        echo "This is my constructor for class animal";
    }
}
$animal1 = new Animal;
echo "<br>";
echo "<br>";

$animal2 = new Animal;
echo "<br>";
echo "<br>";


// constructor with arguments:-

class Employee{
    public $name;
    public $salary;

    function __construct($name, $salary){
        $this->name = $name;
        $this->salary = $salary;
    }

}

$employee1 = new Employee("Tarik", 100000);
echo $employee1->name;
echo "<br>";
echo "<br>";
echo $employee1->salary;
echo "<br>";
echo "<br>";

$employee2 = new Employee("Rohan", 20000);
echo $employee2->name;
echo "<br>";
echo "<br>";
echo $employee2->salary;
?>