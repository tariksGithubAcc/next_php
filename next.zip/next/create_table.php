<?php

// creating table by connecting with database:-

$servername = "localhost";
$username = "root";
$password = "";
$database = "tarik2";

$conn = mysqli_connect($servername, $username, $password, $database);

$sql = 'CREATE TABLE `second_table` (`sno` INT(10) NOT NULL AUTO_INCREMENT , `name` VARCHAR(20) NOT NULL , `age` INT(11) NOT NULL , `doj` DATETIME NOT NULL , PRIMARY KEY (`sno`)) ';

$result = mysqli_query($conn, $sql);
echo "Table created successfully $result";

?>