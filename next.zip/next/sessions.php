<?php

session_start();
$_SESSION['username'] = "Tarik";
$_SESSION['favourite_category'] = "Youtube";
echo "WE have saved your session";

?>