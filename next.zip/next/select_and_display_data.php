
<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "contacts";

$conn = mysqli_connect($servername, $username, $password, $database);

echo "Connection was successfull";

echo "<br>";
echo "<br>";


$sql = "SELECT * FROM `contactus`";
$result = mysqli_query($conn, $sql);

$num = mysqli_num_rows($result);
echo $num;

echo "<br>";
echo "<br>";

// Display the selected records from database table :-

while($rows = mysqli_fetch_assoc($result)){
    echo var_dump($rows);
    echo "<br>";
    echo "<br>";
}

// Display some specific records from database table :-
$sql = "SELECT * FROM `contactus` WHERE `email` = 'bobby@gmail.com'";
$result = mysqli_query($conn, $sql);

$num = mysqli_num_rows($result);
$no = 1;

while($rows = mysqli_fetch_assoc($result)){
    echo $no . "Hello" . $rows['name'] . "Your email is" . $rows['email'];
    $no = $no + 1;
    echo "<br>";
    echo "<br>";
}

?>