<?php

// While loop:- 

$i = 0;
while($i<45){
    echo $i;
    echo "<br>";
    $i++;
}

// For loop:-

for($i=0; $i<45; $i++){
    echo "The value of this variable is $i";
    echo "<br>";
}

// do while loop:-

$t = 0;

do{
    echo "The value of t is $t";
    $t++;
    echo "<br>";
}while($t<10);

// Iterate elements of array using for loop:-

$fruits = array("Banana", "Apple", "Cherry", "Mango", "Grapes");
for($i=0; $i<count($fruits); $i++){
    echo $fruits[$i];
    echo "<br>";

    echo "<br>";
}

$ipl_teams = array("rcb", "csk", "kkr", "gt", "pbks", "dc", "lsg", "srh", "mi");

foreach($ipl_teams as $value) {
    echo $value;
    echo "<br>";

    echo "<br>";
    
}
?>