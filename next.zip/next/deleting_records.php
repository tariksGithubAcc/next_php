<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "tarik2";

$conn = mysqli_connect($servername, $username, $password, $database);

echo "Connection was successfull";

echo "<br>";
echo "<br>";


$sql = "DELETE FROM `second_table` WHERE `second_table`.`name` = 'Rainbow School' LIMIT 11";
$result = mysqli_query($conn, $sql);

if($result){
    echo "Records successfully deleted";
}
else{
    echo "Records did not get deleted due to" . mysqli_error($conn);
}

?>