<?php

readfile('myfile.txt');


?>