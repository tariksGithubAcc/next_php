<?php

$fptr = fopen("randwa_file.txt", "w");
fwrite($fptr, "Dhiman khaandaan randwa hai saalon ne mera beda gark karke rakh diya mardarchod kahin ke bhonsadi wale bhen ke lode");

?>