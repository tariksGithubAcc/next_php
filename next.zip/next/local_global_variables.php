<?php

// Local Variable:-

function print_local_variable(){
    $a = 45;
    echo "The value of this variable a is $a";
}

print_local_variable();
echo "<br>";
echo "<br>";

// Global Variable:-

$b = 56;
function print_global_variable(){
    global $b;
    $b = 100;
    echo "The value of variable b is $b";
}

print_global_variable();

echo "<br>";
echo "<br>";

// Print GLOBALS associative array:-
echo var_dump($GLOBALS);

?>