<?php

$name = "Tarik";
$income = 200000;

echo "This guy is $name and his income is $income";
echo "<br>";

echo "Good Work";

?>