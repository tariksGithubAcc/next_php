<?php

echo "Hello Tarik Dhiman";

?>