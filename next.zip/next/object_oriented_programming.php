<?php

class Animal{

    public $name;
    public $speed;

    function set_name($name){
        $this->name = $name;
    }

    function get_name(){
        return $this->name;
    }
}

$animal1 = new Animal();
$animal1->set_name("Kamodo Dragon");
echo $animal1->get_name();

echo "<br>";
echo "<br>";


?>