<?php

$fptr = fopen("myfile.txt", "r");

$content = fread($fptr, filesize("myfile.txt"));
echo $content;
echo "<br>";
echo "<br>";

fclose($fptr);



?>