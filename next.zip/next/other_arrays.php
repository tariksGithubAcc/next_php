<?php

// Associative array:-
$fav_team = array('Tarik' => 'RCB', 'Nitish' => 'MI', 'Haider' => 'SRH');

foreach($fav_team as $key => $value) {
    echo "Favourite IPL team of $key is $value";
    echo "<br>";
    echo "<br>";
}

// Multidimensional Array:-

$matrix = array(array(2,3,5),
array(1,5,6),
array(7,8,9));

for($i=0; $i<count($matrix); $i++){
    echo var_dump($matrix[$i]);
    echo "<br>";
    echo "<br>";
}

for($i=0; $i<count($matrix); $i++){
    for($j=0; $j<count($matrix[$i]); $j++){
        echo ($matrix[$i][$j]);
        echo " ";
        echo " ";
        echo " ";
        
    }
    echo "<br>";
        echo "<br>";
}
?>