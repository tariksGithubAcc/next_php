<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "contacts";

$conn = mysqli_connect($servername, $username, $password, $database);

echo "Connection was successfull";
echo "<br>";
echo "<br>";

$sql = "UPDATE `contactus` SET `email` = 'dunger@dunger.com' WHERE `contactus`.`sno` = 4";
$result = mysqli_query($conn, $sql);

if($result){
    echo "Record updated successfully";
    echo "<br>";
    echo "<br>";

}
else{
    echo "Record did not updated successfully due to" . mysqli_error($conn);
}

$affected_rows = mysqli_affected_rows($conn);
echo "Number of affected rows are $affected_rows";

?>