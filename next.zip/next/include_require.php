<?php

include 'connectivity.php';

// List number of records in database table:-

$sql = "SELECT * FROM `contactus`";
$result = mysqli_query($conn, $sql);

echo "<br>";
echo "<br>";

$num = mysqli_num_rows($result);
echo "Records found in database table are" . $num;

echo "<br>";
echo "<br>";

while($rows = mysqli_fetch_assoc($result)){
    echo var_dump($rows);   
}

?>