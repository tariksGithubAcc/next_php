<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1>Rules for creating variables in PHP</h1>
        <ul>
            <li>
                starts with $ symbol
            </li>
            <li>
                cannot start with number or different symbol
            </li>
        </ul>
    </div>
</body>
</html>