<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "tarik2";

$conn = mysqli_connect($servername, $username, $password, $database);

$name = 'Rainbow School';
$age = '2000';


$sql = "INSERT INTO `second_table` (`sno`, `name`, `age`, `doj`) VALUES (NULL, '$name', '$age', '2024-04-05 08:18:30.000000')";
$result = mysqli_query($conn, $sql);

echo "Data Inserted successfully";



?>