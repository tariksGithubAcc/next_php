<?php

function processmarks($marks_arr){
    $sum = 0;
    foreach ($marks_arr as $value) {
        $sum += $value;
    }
    return $sum;
}

$rohan_das = array(20,12,45,78,98);
$total_marks = processmarks($rohan_das);

echo "Marks scored by rohan das is $total_marks";
echo "<br>";

// Find average of these marks:-
function avg_marks($marks_arr){
    $sum = 0;
    $i = 1;
    foreach ($marks_arr as $value) {
        $sum += $value;
        $i++;
    }
    return $sum/$i;
}

$rohan_das = array(20,12,45,78,98);
$average_marks = avg_marks($rohan_das);

echo "Average Marks scored by rohan das is $average_marks";
echo "<br>";

// Date function :-

$d = date("dS F Y");
echo "Today's date is $d";
echo "<br>";
?>