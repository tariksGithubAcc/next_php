<?php

// variables:-

$a = "Tarik";
echo $a;
echo "<br>";
echo "<br>";

// Data Types:-
// Boolean:-

$bool1 = True;
$bool2 = False;

echo "Print true if value of bool1 is true" . var_dump($bool1);
echo "<br>";
echo "<br>";
echo "Print false if value of bool2 is false" . var_dump($bool2);
echo "<br>";
echo "<br>";

// Array:-

$fruits = array("Mango","Apple","Banana","Grpaes","Papaya","Orange");
for($i=0; $i<count($fruits); $i++){
    echo $fruits[$i];
    echo "<br>";
    echo "<br>";
}

// String Functions:-
// String reverse, string replace, string repeat, string search:-

$string = "Tarik Dhiman";
echo strrev($string);
echo "<br>";
echo "<br>";

echo str_replace($string, "Tarik Dhiman","Lajesh Dhiman");
echo "<br>";
echo "<br>";

echo str_repeat($string, 150);
echo "<br>";
echo "<br>";

echo strpos($string, "Dhiman");
echo "<br>";
echo "<br>";

// Operators:-
// Airthmatic, assignment, logical, comparision, relational:-

$num1 = 10;
$num2 = 10;

echo "The sum of both these numbers is" . ($num1+$num2);
echo "<br>";
echo "<br>";

$value1 = True;
$value2 = True;

echo "Returns True if both values are true" . var_dump($value1 && $value2);
echo "<br>";
echo "<br>";

$number1 = 10;
$number2 = 20;

if($number1 > $number2){
    echo "$number1 is greater";
}
else{
    echo "$number2 is greater";
}
echo "<br>";
echo "<br>";

// Switch case statement:-

$age = 45;

switch($age){
    case 22:
        echo "You can drive the car if you are having driving license";
        echo "<br>";
        echo "<br>";

    case 45:
        echo "You can drink alcohol";
        echo "<br>";
        echo "<br>";

    default:
        echo "This is switch case";
        echo "<br>";
        echo "<br>";
}
echo "<br>";
echo "<br>";

// loops:-
// for, while, do while, foreach:-

$val = 0;
while($val<10){
    echo $val;
    $val++;
    echo "<br>";
    echo "<br>";
}
echo "<br>";
echo "<br>";

echo "Now comes the do while loop:-";
echo "<br>";
echo "<br>";

$val1 = 1;
do{
    echo $val1;
    $val1++;
    echo "<br>";
    echo "<br>";
}while($val1<20);

echo "<br>";
echo "<br>";

echo "Now comes the foreach loop:-";
echo "<br>";
echo "<br>";

$friends = ["Tarik","Shwetanshu","Mayank","Udit","Yuvraj"];
foreach($friends as $value){
    echo $value;
    echo "<br>";
    echo "<br>";
}

echo "<br>";
echo "<br>";

// functions taking example of local and global variable:-

function local_variable(){
    $tarik = "Tarik Dhiman";
    echo "$tarik ne B.tech kiya hai";
    echo "<br>";
    echo "<br>";
}
$local = local_variable();

echo "<br>";
echo "<br>";

$global = 10;

function global_variable(){
    global $global;
    echo "The value of variable is $global";
    echo "<br>";
    echo "<br>";

}
$global_var = global_variable();
echo "<br>";
echo "<br>";

// Super global:-

echo "This is Super Global:-";
echo "<br>";
echo "<br>";

echo var_dump($GLOBALS);
echo "<br>";
echo "<br>";

echo date("dS F Y");
echo "<br>";
echo "<br>";

$favourite_ipl_teams = array("Tarik"=>"RCB",
"Nitish"=>"MI",
"Haider"=>"SRH");

foreach($favourite_ipl_teams as $key => $value){
    echo "Favourite IPL teams of $key is $value";
    echo "<br>";
    echo "<br>";
}
echo "<br>";
echo "<br>";

$matrix = array(array(1,2,3),
array(4,5,6),
array(7,8,9));

for($i=0; $i<count($matrix); $i++){
    for($j=0; $j<count($matrix[$i]); $j++){
        echo ($matrix[$i][$j]);
        echo " ";
        echo " ";
        echo " ";
       
    }
    echo "<br>";
echo "<br>";
}

function process_marks($marks_arr){
    $sum = 0;
    foreach($marks_arr as $value){
        $sum += $value;
    }
    return $sum;
}
$marks_ka_arr = array(1,2,3,4,5);
$pm = process_marks($marks_ka_arr);

echo "The sum of marks scored by this student is $pm";
echo "<br>";
echo "<br>";

echo "Include and Require:-";
echo "<br>";
echo "<br>";

include 'private.txt';

echo "<br>";
echo "<br>";

echo "Working with files:-";
echo "<br>";
echo "<br>";

$fptr = fopen("public.txt", "r");
$content = fread($fptr, filesize("public.txt"));
echo $content;

fclose($fptr);
echo "<br>";
echo "<br>";

// while($a=fgets($fptr)){
//     echo $a;
//     echo "<br>";
//     echo "<br>";
// }

// echo "<br>";
// echo "<br>";

$file_ptr = fopen("randwa.txt", "w");
$context = fwrite($file_ptr, "Teri maa ki hat");
echo $context;
echo "<br>";
echo "<br>";

class Animal{

    public $name;
    public $speed;

    function set_name($name){
        $this->name = $name;
    }

    function get_name(){
        return $this->name;
    }
}

$animal1 = new Animal();
$animal1->set_name("Kamodo Dragon");
echo $animal1->get_name();

echo "<br>";
echo "<br>";

class family_members{

    public $naam;
    public $umar;

    function __construct($naam, $umar){
        $this->naam = $naam;
        $this->umar = $umar;
    }
}

$fm1 = new family_members("Tarik", 22);
echo $fm1->naam;
echo "<br>";
echo "<br>";

echo $fm1->umar;
echo "<br>";
echo "<br>";

$fm2 = new family_members("Lajesh", 45);
echo $fm2->naam;
echo "<br>";
echo "<br>";

echo $fm2->umar;
echo "<br>";
echo "<br>";

?>