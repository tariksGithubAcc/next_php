<?php

session_start();
echo "Welcome" . $_SESSION['username'];
echo "<br>";
echo "<br>";
echo "Your favourite category is " . $_SESSION['favourite_category'];


?>