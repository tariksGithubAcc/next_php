<?php

echo 20+30;

?>