<?php

$age = 45;

switch($age){
    case 1:
        echo "You are 17 years old";
        // break;
        echo "<br>";

    case 45:
        echo "You are 45 years old";
        // break;
        echo "<br>";

    case 65:
        echo "You are 65 years old";
        // break;
        echo "<br>";

    case 99:
        echo "You are 99 years old";
        // break;
        echo "<br>";

    default:
    echo "Done";
}





?>