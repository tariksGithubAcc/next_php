<?php

// reading the content of the file line by line:-
$fptr = fopen("second_text_file.txt", "r");

while($a = fgets($fptr)){
    echo $a;
    echo "<br>";
    echo "<br>";
    
}

?>