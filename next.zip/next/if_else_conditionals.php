<?php

$age = 45;

if($age>14){
    echo "age is greater than 14";
}
else{
    echo "age is not greater than 14";
}

echo "<br>";
// If else ladder:-

$umar = 78;

if($umar>55){
    echo "umar is greater than 55";
}

elseif($umar>88){
    echo "umar is greater than 55";
}
else{
    echo "invalid umar";
}
echo "<br>";
// quiz:-

$umar_age = 25;

if($umar_age>25 && $umar_age<65){
    echo "You can drive the car";
}
else{
    echo "You cannot drive the car";
}

?>